from django.db import models

# Create your models here.

class Customers(models.Model):
    IdCustomers =models.IntegerField()
    Name = models.CharField(max_length=50)
    Family = models.CharField(max_length=50)
    Address = models.TextField()
    Phone = models.CharField(max_length=10)
    Pic= models.ImageField(null=True, blank=True)
    SizeOfProduct = models.CharField(max_length=10)