from django.http import HttpResponse
import datetime
from .models import *
from rest_framework import routers, serializers, viewsets 
from .serializers import CustomersSerializer
from rest_framework import generics
from rest_framework import status, pagination, mixins
from rest_framework.response import Response
class UserViewSet(generics.GenericAPIView):
    queryset = Customers.objects.all()
    serializer_class = CustomersSerializer
    def get(self, request, format='json'):
        serializer = self.get_serializer(self.get_queryset(), many=True)
        if serializer.data:
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.data, status=status.HTTP_404_NOT_FOUND)
    def post(self, request, format='json'):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(data=serializer.data, status=status.HTTP_201_CREATED)
        

