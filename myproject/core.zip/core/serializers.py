from django.urls import path, include
from .models import *
from rest_framework import routers, serializers, viewsets

# Serializers define the API representation.

class CustomersSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customers
        fields = ['IdCustomers', 'Name', 'Family', 'Address','Phone','Pic','SizeOfProduct']